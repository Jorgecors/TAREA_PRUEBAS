package com.example.calculadora1;

public class Calculadora {

    public static int sumar(int numero1, int numero2) {
        return numero1 + numero2;
    }
}
