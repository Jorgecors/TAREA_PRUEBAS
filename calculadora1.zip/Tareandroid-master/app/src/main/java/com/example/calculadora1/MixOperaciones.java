package com.example.calculadora1;

public class MixOperaciones {

    public static int sumarYMultiplicar(int numero1, int numero2, int numero3) {
        int suma = numero1 + numero2;
        int multiplicacion = suma * numero3;
        return multiplicacion;
    }
}
