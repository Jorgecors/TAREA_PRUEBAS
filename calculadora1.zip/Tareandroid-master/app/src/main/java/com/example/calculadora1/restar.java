package com.example.calculadora1;

public class restar {

    public static int restar(int numero1, int numero2) {
        return numero1 - numero2;
    }
}
